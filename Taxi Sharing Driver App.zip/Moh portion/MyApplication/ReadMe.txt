ReadMe - Honours Project

Mohamed Gahelrasoul - 101007118
Supervisor: Dr. Doron Nussbaum
April 22nd, 2019

Location of Source Code
-----------------------
Taxi Sharing Driver.zip\MyApplication\app\src\main\java\mohgahel\myapplication


Layout of Project in Android Studio
------------------------------------
app -> src -> main -> java
	This folder contains all the java files for the application
	Each file corresponds to an xml file of the same name (the xml files all begin with activity followed by the name given)
		Each of these files is the back end code for that xml file
		
app -> src -> main -> res
	This folder contains all the xml files for the application
	Each file corresponds to a java file of the same name
		Each of these files is the front end design for that java file




To open and run the android studio project:
-----------------------------------
	Open the project in Android Studio
	Plug in an Android device to the computer and run the application
	Android Studio will download the APK to your device and open your app.


